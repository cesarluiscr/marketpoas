import { db } from '@/lib/db'

// Coordenadas aproximadas de los distritos del cantón de Poás
const DISTRICT_COORDS: Record<string, { lat: number; lng: number }> = {
  'San Pedro': { lat: 10.0746, lng: -84.2336 },
  'San Juan': { lat: 10.0587, lng: -84.2167 },
  'San Rafael': { lat: 10.0420, lng: -84.2080 },
  'Carrillos': { lat: 10.0920, lng: -84.2510 },
  'Sabana Redonda': { lat: 10.1080, lng: -84.2230 },
}

const sampleListings = [
  {
    type: 'venta',
    title: 'Café fresco de Poás - 5 libras',
    description: 'Café recién tostado de mi finca en San Pedro de Poás. Grano oscuro, molido al gusto. Recogido el mismo día del tostado.',
    price: 8000,
    currency: 'CRC',
    category: 'Alimentos',
    condition: 'nuevo',
    location: 'San Pedro',
    imageUrl: 'https://images.unsplash.com/photo-1559525839-d9acfd0f2a14?w=800&q=80',
    contactName: 'Don Mario Sánchez',
    contactPhone: '8821-4567',
    contactWhatsapp: '50688214567',
  },
  {
    type: 'venta',
    title: 'Bicicleta montaña 27.5"',
    description: 'Bicicleta Trek Marlin 7, talla M, 21 velocidades, frenos de disco hidráulicos. Poco uso, excelente estado. Incluye candado y bomba.',
    price: 280000,
    currency: 'CRC',
    category: 'Vehículos',
    condition: 'seminuevo',
    location: 'San Pedro',
    imageUrl: 'https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?w=800&q=80',
    contactName: 'Carlos Ramírez',
    contactPhone: '8456-7890',
    contactWhatsapp: '50684567890',
  },
  {
    type: 'venta',
    title: 'Escritorio de madera maciza',
    description: 'Escritorio de cerezo, 1.20m x 0.60m, con cajón. Madera maciza, muy sólido. Ideal para home office. Traslado por cuenta del comprador.',
    price: 75000,
    currency: 'CRC',
    category: 'Muebles',
    condition: 'usado',
    location: 'San Juan',
    imageUrl: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba5bd?w=800&q=80',
    contactName: 'María González',
    contactPhone: '8834-2211',
    contactWhatsapp: '50688342211',
  },
  {
    type: 'compra',
    title: 'COMPRO gallinas ponedoras',
    description: 'Busco gallinas ponedoras (raza Leghorn o Rhode Island) para mi patio. Pago buen precio por lotes de 5 a 10 gallinas sanas. En el cantón de Poás.',
    price: 12000,
    currency: 'CRC',
    category: 'Animales',
    condition: 'usado',
    location: 'San Rafael',
    imageUrl: 'https://images.unsplash.com/photo-1548550023-2bdba5d8b71c?w=800&q=80',
    contactName: 'José Vargas',
    contactPhone: '8901-2345',
    contactWhatsapp: '50689012345',
  },
  {
    type: 'venta',
    title: 'Fresno eléctrico podador',
    description: 'Podador eléctrico Mark 18V con batería y cargador. Poco uso, en caja original. Ideal para mantener setos en el jardín.',
    price: 95000,
    currency: 'CRC',
    category: 'Herramientas',
    condition: 'seminuevo',
    location: 'San Pedro',
    imageUrl: 'https://images.unsplash.com/photo-1572626461310-5c1a39d5e74e?w=800&q=80',
    contactName: 'Roberto Mora',
    contactPhone: '8777-3344',
    contactWhatsapp: '50687773344',
  },
  {
    type: 'venta',
    title: 'Tanque de agua 1000 litros',
    description: 'Tanque plástico de 1000 litros, color beige, en buen estado. Con conexión para tubo de 1 pulgada. Ideal para casa de campo.',
    price: 45000,
    currency: 'CRC',
    category: 'Hogar',
    condition: 'usado',
    location: 'San Juan',
    imageUrl: 'https://images.unsplash.com/photo-1581094736241-9f8c0e1d8c8e?w=800&q=80',
    contactName: 'Familia Rojas',
    contactPhone: '8321-9988',
    contactWhatsapp: '50683219988',
  },
  {
    type: 'venta',
    title: 'Plantas ornamentales de interior',
    description: 'Vento collection de plantas: costilla de Adán, lengua de suegra, potos, peperomia. Macetas decorativas de cerámica incluidas. Precios desde ₡3500.',
    price: 3500,
    currency: 'CRC',
    category: 'Jardín',
    condition: 'nuevo',
    location: 'Carrillos',
    imageUrl: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800&q=80',
    contactName: 'Luisa Castro',
    contactPhone: '8445-6789',
    contactWhatsapp: '50684456789',
  },
  {
    type: 'compra',
    title: 'COMPRO refrigeradora pequeña',
    description: 'Busco refrigeradora de 4 pies cúbicos, en buen estado. Para apartamento en San Pedro. Pago hasta ₡80.000 según estado.',
    price: 80000,
    currency: 'CRC',
    category: 'Electrodomésticos',
    condition: 'usado',
    location: 'San Pedro',
    imageUrl: 'https://images.unsplash.com/photo-1571175443880-159ccbf1a4f4?w=800&q=80',
    contactName: 'Ana Viquez',
    contactPhone: '8567-1212',
    contactWhatsapp: '50685671212',
  },
  {
    type: 'venta',
    title: 'Terreno 200 m² en Carrillos',
    description: 'Lote plano de 200 m² con todos los servicios (agua, luz, internet). Vista a la cordillera. Listo para construir. Escrituras al día.',
    price: 8500000,
    currency: 'CRC',
    category: 'Inmuebles',
    condition: 'nuevo',
    location: 'Carrillos',
    imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80',
    contactName: 'Gestoría Vargas',
    contactPhone: '2448-1234',
    contactWhatsapp: '50624481234',
  },
  {
    type: 'venta',
    title: 'Clases de matemáticas a domicilio',
    description: 'Profesor universitario ofrece clases de matemáticas para primaria y secundaria. A domicilio en todo el cantón de Poás. ₡8000/hora.',
    price: 8000,
    currency: 'CRC',
    category: 'Servicios',
    condition: 'nuevo',
    location: 'San Pedro',
    imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&q=80',
    contactName: 'Prof. Esteban Ureña',
    contactPhone: '8678-4567',
    contactWhatsapp: '50686784567',
  },
  {
    type: 'venta',
    title: 'Sofá de 3 plazas tela beige',
    description: 'Sofá cómodo de 3 plazas, tela fácil de limpiar, estructura de madera. Sin manchas ni roturas. Se muda y no entra en el nuevo apartamento.',
    price: 60000,
    currency: 'CRC',
    category: 'Muebles',
    condition: 'usado',
    location: 'San Juan',
    imageUrl: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=800&q=80',
    contactName: 'Patricia Núñez',
    contactPhone: '8909-4455',
    contactWhatsapp: '50689094455',
  },
  {
    type: 'venta',
    title: 'Huevos frescos de gallina feliz',
    description: 'Vendo huevos de gallinas criadas libres en mi patio en San Rafael. Docena ₡3000. Disponibilidad de 10 a 30 docenas por semana.',
    price: 3000,
    currency: 'CRC',
    category: 'Alimentos',
    condition: 'nuevo',
    location: 'San Rafael',
    imageUrl: 'https://images.unsplash.com/photo-1582722872445-44dc5f43e674?w=800&q=80',
    contactName: 'Finca El Roble',
    contactPhone: '8411-2233',
    contactWhatsapp: '50684112233',
  },
  {
    type: 'venta',
    title: 'Fresas frescas del volcán',
    description: 'Fresas frescas cultivadas a 2000m de altura en Sabana Redonda. Caja de 1 libra ₡2500. Recogidas el mismo día, súper dulces.',
    price: 2500,
    currency: 'CRC',
    category: 'Alimentos',
    condition: 'nuevo',
    location: 'Sabana Redonda',
    imageUrl: 'https://images.unsplash.com/photo-1464965931866-4e1e1e0d1e7b?w=800&q=80',
    contactName: 'Fresa Volcán Poás',
    contactPhone: '8732-5566',
    contactWhatsapp: '50687325566',
  },
  {
    type: 'venta',
    title: 'Caballo de montaña con silla',
    description: 'Caballo criollo de 8 años, manso, ideal para paseos por los senderos de Poás. Incluye silla de montar y brida. Documentación al día.',
    price: 450000,
    currency: 'CRC',
    category: 'Animales',
    condition: 'usado',
    location: 'Carrillos',
    imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3c82d5fc?w=800&q=80',
    contactName: 'Don Rafael Mora',
    contactPhone: '8899-1212',
    contactWhatsapp: '50688991212',
  },
  {
    type: 'compra',
    title: 'COMPRAMOS café en cereza',
    description: 'Beneficio en San Pedro compra café en cereza a precio competitivo. Recogida en finca para lotes mayores a 1 fanega. Pago al día.',
    price: 35000,
    currency: 'CRC',
    category: 'Alimentos',
    condition: 'nuevo',
    location: 'San Pedro',
    imageUrl: 'https://images.unsplash.com/photo-1447933601403-43ed68de7d4f?w=800&q=80',
    contactName: 'Beneficio Don Poás',
    contactPhone: '2448-9988',
    contactWhatsapp: '50624489988',
  },
  {
    type: 'venta',
    title: 'Fertilizante orgánico (bocashi)',
    description: 'Sacos de 50 libras de abono orgánico bocashi, ideal para hortalizas y café. Elaborado con residuos de fincas de Poás. ₡4000 el saco.',
    price: 4000,
    currency: 'CRC',
    category: 'Jardín',
    condition: 'nuevo',
    location: 'San Juan',
    imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b9b?w=800&q=80',
    contactName: 'Compost Poás',
    contactPhone: '8444-7788',
    contactWhatsapp: '50684447788',
  },
]

async function main() {
  console.log('Seeding database with sample listings...')
  // Clear existing
  await db.listing.deleteMany({})
  for (const listing of sampleListings) {
    // Añadir lat/lng según el distrito
    const coords = DISTRICT_COORDS[listing.location] ?? DISTRICT_COORDS['San Pedro']
    const lat = coords.lat + (Math.random() - 0.5) * 0.012
    const lng = coords.lng + (Math.random() - 0.5) * 0.012

    // Añadir campos meta según categoría
    const meta: any = {}
    if (listing.category === 'Alimentos') {
      meta.metaWeight = '5 libras'
    } else if (listing.category === 'Vehículos' && listing.title.includes('Bicicleta')) {
      meta.metaBrand = 'Trek'
      meta.metaModel = 'Marlin 7'
      meta.metaYear = 2022
    } else if (listing.category === 'Inmuebles') {
      meta.metaAreaM2 = 200
      meta.metaBedrooms = 0
      meta.metaBathrooms = 0
    } else if (listing.category === 'Electrodomésticos') {
      meta.metaBrand = 'LG'
      meta.metaCapacity = '4 pies cúbicos'
    } else if (listing.category === 'Herramientas') {
      meta.metaBrand = 'Makita'
      meta.metaModel = '18V'
    }

    await db.listing.create({
      data: {
        ...listing,
        lat,
        lng,
        ...meta,
      } as any,
    })
  }
  console.log(`Seeded ${sampleListings.length} sample listings.`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
